set names utf8mb4;
set charset utf8mb4;
drop database if exists productiedatabase;
create database productiedatabase charset utf8mb4;
use productiedatabase;
grant all on * to cursist;