set names utf8mb4;
set charset utf8mb4;
drop database if exists ontwikkeldatabase;
create database ontwikkeldatabase charset utf8mb4;
use ontwikkeldatabase;
grant all on * to cursist;
