package be.vdab;

import org.apache.commons.text.WordUtils;

class Main {

	public static void main(String[] args) {
		System.out.println(WordUtils.swapCase("VDAB doet met je mee!"));
	}

}
